import Foundation

/* 4. Para tipos de datos, declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a un número entero, 
un número decimal (flotante), una cadena de texto, realizando la asignación explícita y la asignación inferida.  */

var n1: Int = 1
var n2 = 2
var numdec1: Float = 1.1
var numdec2 = 1.2
var txt1: String = "Texto 1"
var txt2 = "Texto 2"

/* Para Asociación de tipos, declara el tipo de dato por asociación para un tipo de dato String y Declara el 
tipo de dato por asociación para un tipo de dato número entero.  */

let otro_numero: Int = 3
let otro_texto: String = "Texto 3"

/* 6. Para Arreglos y Diccionarios, crea la variable números de tipo Array con números consecutivos del 1 a 10 y 
luego crea la variable diasSemana de tipo Dictionary con la relación numero:día Ej. 1:"Lunes” */

var Nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
var Dias = ["Lunes": 1, "Martes": 2, "Miercoles": 3, "Jueves": 4, "Viernes": 5, "Sabado": 6, "Domingo": 7]